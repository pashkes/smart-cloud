//@prepros-prepend plugins/pgwBrowser.js
